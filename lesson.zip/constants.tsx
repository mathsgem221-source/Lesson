
import { TextbookLink, NIELink, GradeCurriculum } from './types';

export const CURRICULUM: GradeCurriculum[] = [
  {
    grade: "6",
    lessons: [
      { id: "6-1", term: 1, name: "வட்டம்", periods: 3, subUnits: [{ id: "1.1", name: "வட்டம் அறிமுகம்" }, { id: "1.2", name: "வட்டத்தின் பகுதிகள்" }] },
      { id: "6-2", term: 1, name: "இடப்பெறுமானம்", periods: 6, subUnits: [{ id: "2.1", name: "எண்களை வாசித்தல்" }, { id: "2.2", name: "இடப்பெறுமானம் காணல்" }] },
      { id: "6-3", term: 1, name: "முழுஎண்களில் கணிதச்செய்கைகள்", periods: 10, subUnits: [{ id: "3.1", name: "கூட்டல்" }, { id: "3.2", name: "கழித்தல்" }, { id: "3.3", name: "பெருக்கல்" }, { id: "3.4", name: "வகுத்தல்" }] },
      { id: "6-4", term: 1, name: "காலம்", periods: 6, subUnits: [{ id: "4.1", name: "நேரத்தை அளத்தல்" }, { id: "4.2", name: "கால அலகுகள்" }] },
      { id: "6-5", term: 1, name: "எண்கோடு", periods: 8, subUnits: [{ id: "5.1", name: "மறை எண்கள்" }, { id: "5.2", name: "எண்கோட்டில் குறித்தல்" }] },
      { id: "6-6", term: 1, name: "மதிப்பிடலும் மட்டந்தட்டலும்", periods: 5, subUnits: [{ id: "6.1", name: "கிட்டிய 10 இற்கு மட்டந்தட்டல்" }] },
      { id: "6-7", term: 1, name: "கோணங்கள்", periods: 5, subUnits: [{ id: "7.1", name: "கோணங்களின் வகைகள்" }] },
      { id: "6-8", term: 2, name: "திசைகள்", periods: 4, subUnits: [{ id: "8.1", name: "பிரதான திசைகள்" }] },
      { id: "6-9", term: 2, name: "பின்னங்கள்", periods: 12, subUnits: [{ id: "9.1", name: "முறைமைப் பின்னங்கள்" }, { id: "9.2", name: "சமவலுப் பின்னங்கள்" }] },
      { id: "6-10", term: 2, name: "தெரிதல்", periods: 4, subUnits: [{ id: "10.1", name: "கூட்டமாக்குதல்" }] },
      { id: "6-11", term: 2, name: "காரணிகளும் மடங்குகளும்", periods: 8, subUnits: [{ id: "11.1", name: "காரணிகள்" }, { id: "11.2", name: "மடங்குகள்" }] },
      { id: "6-12", term: 2, name: "நேர்கோட்டுத் தளவுருக்கள்", periods: 4, subUnits: [{ id: "12.1", name: "தளவுருக்களின் இயல்புகள்" }] },
      { id: "6-13", term: 2, name: "தசமங்கள்", periods: 6, subUnits: [{ id: "13.1", name: "தசம எண்கள்" }, { id: "13.2", name: "தசமக் கூட்டல் கழித்தல்" }] },
      { id: "6-14", term: 2, name: "எண்வகைகளும் எண்கோலங்களும்", periods: 8, subUnits: [{ id: "14.1", name: "சதுர, முக்கோண எண்கள்" }] },
      { id: "6-15", term: 2, name: "நீளம்", periods: 6, subUnits: [{ id: "15.1", name: "நீளத்தை அளத்தல்" }] },
      { id: "6-16", term: 2, name: "திரவ அளவீடு", periods: 4, subUnits: [{ id: "16.1", name: "லீற்றர், மில்லிலீற்றர்" }] },
      { id: "6-17", term: 2, name: "திண்மங்கள்", periods: 6, subUnits: [{ id: "17.1", name: "திண்மங்களின் இயல்புகள்" }] },
      { id: "6-18", term: 3, name: "அட்சரகணிதக் குறியீடுகள்", periods: 4, subUnits: [{ id: "18.1", name: "மாறிகள் அறிமுகம்" }] },
      { id: "6-19", term: 3, name: "அட்சரகணிதக் கோவை உருவாக்கலும் பிரதியிடலும்", periods: 6, subUnits: [{ id: "19.1", name: "கோவை உருவாக்கம்" }, { id: "19.2", name: "பிரதியிடல்" }] },
      { id: "6-20", term: 3, name: "திணிவு", periods: 5, subUnits: [{ id: "20.1", name: "கிராம், கிலோகிராம்" }] },
      { id: "6-21", term: 3, name: "விகிதம்", periods: 5, subUnits: [{ id: "21.1", name: "விகிதம் அறிமுகம்" }] },
      { id: "6-22", term: 3, name: "தரவுகளை சேகரித்தலும் வகைகுறித்தலும்", periods: 6, subUnits: [{ id: "22.1", name: "தரவுச் சேகரிப்பு" }] },
      { id: "6-23", term: 3, name: "தரவுகளுக்கு விளக்கம் கூறல்", periods: 4, subUnits: [{ id: "23.1", name: "வரைபுகள் மூலம் விளக்கம்" }] },
      { id: "6-24", term: 3, name: "சுட்டிகள்", periods: 4, subUnits: [{ id: "24.1", name: "சுட்டி வடிவம்" }] }
    ]
  },
  {
    grade: "7",
    lessons: [
      { id: "7-1", term: 1, name: "இருபுடைச் சமச்சீர்", periods: 4, subUnits: [{ id: "1.1", name: "சமச்சீர் அச்சுகள்" }] },
      { id: "7-2", term: 1, name: "தொடைகள்", periods: 5, subUnits: [{ id: "2.1", name: "தொடைகள் அறிமுகம்" }] },
      { id: "7-3", term: 1, name: "முழுஎண்களுடனான கணிதச் செய்கைகள்", periods: 8, subUnits: [{ id: "3.1", name: "கணிதச் செய்கை வரிசை" }] },
      { id: "7-4", term: 1, name: "காரணிகளும் மடங்குகளும்", periods: 6, subUnits: [{ id: "4.1", name: "பொ.கா.உ & பொ.ம.சி" }] },
      { id: "7-5", term: 1, name: "சுட்டிகள்", periods: 4, subUnits: [{ id: "5.1", name: "சுட்டி விதிகள்" }] },
      { id: "7-6", term: 1, name: "காலம்", periods: 6, subUnits: [{ id: "6.1", name: "கால இடைவெளிகள்" }] },
      { id: "7-7", term: 1, name: "சமாந்தரக் கோடுகள்", periods: 5, subUnits: [{ id: "7.1", name: "சமாந்தரக் கோடுகளின் இயல்புகள்" }] },
      { id: "7-8", term: 1, name: "திசைகொண்ட எண்கள்", periods: 6, subUnits: [{ id: "8.1", name: "திசைகொண்ட எண் கூட்டல்" }] },
      { id: "7-9", term: 1, name: "கோணங்கள்", periods: 5, subUnits: [{ id: "9.1", name: "கோணங்களின் வகைகள்" }] },
      { id: "7-10", term: 2, name: "பின்னம்", periods: 10, subUnits: [{ id: "10.1", name: "பின்னச் சுருக்கல்" }] },
      { id: "7-11", term: 2, name: "தசமங்கள்", periods: 6, subUnits: [{ id: "11.1", name: "தசமப் பெருக்கம்" }] },
      { id: "7-12", term: 2, name: "அட்சரகணிதக் கோவைகள்", periods: 6, subUnits: [{ id: "12.1", name: "கோவைச் சுருக்கல்" }] },
      { id: "7-13", term: 2, name: "திணிவு", periods: 4, subUnits: [{ id: "13.1", name: "திணிவு அலகுகள்" }] },
      { id: "7-14", term: 2, name: "நேர்கோட்டுத் தளவுருக்கள்", periods: 5, subUnits: [{ id: "14.1", name: "தளவுருக்களின் கோணங்கள்" }] },
      { id: "7-15", term: 2, name: "சமன்பாடுகளும் சூத்திரங்களும்", periods: 8, subUnits: [{ id: "15.1", name: "எளிய சமன்பாடுகள்" }] },
      { id: "7-16", term: 2, name: "நீளம்", periods: 5, subUnits: [{ id: "16.1", name: "நீள அளவீடு" }] },
      { id: "7-17", term: 3, name: "பரப்பளவு", periods: 6, subUnits: [{ id: "17.1", name: "சதுரம், செவ்வகம்" }] },
      { id: "7-18", term: 3, name: "வட்டங்கள்", periods: 4, subUnits: [{ id: "18.1", name: "வட்டத்தின் பகுதிகள்" }] },
      { id: "7-19", term: 3, name: "கனவளவு", periods: 5, subUnits: [{ id: "19.1", name: "கனவளவு கணித்தல்" }] },
      { id: "7-20", term: 3, name: "திரவ அளவீடு", periods: 4, subUnits: [{ id: "20.1", name: "கொள்ளளவு" }] },
      { id: "7-21", term: 3, name: "விகிதம்", periods: 5, subUnits: [{ id: "21.1", name: "சமவலு விகிதம்" }] },
      { id: "7-22", term: 3, name: "சதவீதம்", periods: 6, subUnits: [{ id: "22.1", name: "சதவீதக் கணக்குகள்" }] },
      { id: "7-23", term: 3, name: "தெக்காட்டின் தளம்", periods: 6, subUnits: [{ id: "23.1", name: "ஆள்கூறுகள்" }] },
      { id: "7-24", term: 3, name: "அமைப்புக்கள்", periods: 6, subUnits: [{ id: "24.1", name: "அடிப்படை அமைப்புகள்" }] },
      { id: "7-25", term: 3, name: "திண்மங்கள்", periods: 4, subUnits: [{ id: "25.1", name: "திண்மங்களின் வலைகள்" }] },
      { id: "7-26", term: 3, name: "தரவுகளை வகைகுறித்தல்", periods: 5, subUnits: [{ id: "26.1", name: "படவரைபு" }] },
      { id: "7-27", term: 3, name: "அளவிடைப்படம்", periods: 5, subUnits: [{ id: "27.1", name: "அளவிடை வரைதல்" }] },
      { id: "7-28", term: 3, name: "தெசலாக்கம்", periods: 3, subUnits: [{ id: "28.1", name: "ஒழுங்கான தெசலாக்கம்" }] },
      { id: "7-29", term: 3, name: "ஒரு நிகழ்தகவின் இயல்தகவு", periods: 4, subUnits: [{ id: "29.1", name: "நிகழ்தகவு அறிமுகம்" }] }
    ]
  },
  {
    grade: "8",
    lessons: [
      { id: "8-1", term: 1, name: "எண்கோலங்கள்", periods: 5, subUnits: [{ id: "1.1", name: "எண்கோலத்தின் பொது உறுப்பு" }] },
      { id: "8-2", term: 1, name: "சுற்றளவு", periods: 5, subUnits: [{ id: "2.1", name: "கூட்டுத் தளவுருக்கள்" }] },
      { id: "8-3", term: 1, name: "கோணங்கள்", periods: 6, subUnits: [{ id: "3.1", name: "அயற்கோணங்கள்" }] },
      { id: "8-4", term: 1, name: "திசைகொண்ட எண்கள்", periods: 5, subUnits: [{ id: "4.1", name: "பெருக்கல் & வகுத்தல்" }] },
      { id: "8-5", term: 1, name: "அட்சரகணிதக் கோவைகள்", periods: 6, subUnits: [{ id: "5.1", name: "அடைப்பு நீக்கல்" }] },
      { id: "8-6", term: 1, name: "திண்மங்கள்", periods: 5, subUnits: [{ id: "6.1", name: "ஒயிலரின் தொடர்பு" }] },
      { id: "8-7", term: 1, name: "காரணிகள்", periods: 6, subUnits: [{ id: "7.1", name: "பொதுக் காரணி" }] },
      { id: "8-8", term: 1, name: "வர்க்கமூலம்", periods: 5, subUnits: [{ id: "8.1", name: "காரணிப்படுத்தும் முறை" }] },
      { id: "8-9", term: 2, name: "திணிவு", periods: 4, subUnits: [{ id: "9.1", name: "மெட்ரிக் தொன்" }] },
      { id: "8-10", term: 2, name: "சுட்டிகள்", periods: 5, subUnits: [{ id: "10.1", name: "சுட்டி விதிகள் அறிமுகம்" }] },
      { id: "8-11", term: 2, name: "சமச்சீர்", periods: 4, subUnits: [{ id: "11.1", name: "சுழல் சமச்சீர்" }] },
      { id: "8-12", term: 2, name: "முக்கோணிகளும் நாற்பக்கல்களும்", periods: 8, subUnits: [{ id: "12.1", name: "கோண இயல்புகள்" }] },
      { id: "8-13", term: 2, name: "பின்னங்கள் 1", periods: 6, subUnits: [{ id: "13.1", name: "பின்னக் கூட்டல் கழித்தல்" }] },
      { id: "8-14", term: 2, name: "பின்னங்கள் 2", periods: 6, subUnits: [{ id: "14.1", name: "பின்னப் பெருக்கல் வகுத்தல்" }] },
      { id: "8-15", term: 2, name: "தசமங்கள்", periods: 5, subUnits: [{ id: "15.1", name: "தசமச் சுருக்கல்கள்" }] },
      { id: "8-16", term: 2, name: "விகிதம்", periods: 5, subUnits: [{ id: "16.1", name: "பங்கீடு" }] },
      { id: "8-17", term: 3, name: "சமன்பாடுகள்", periods: 7, subUnits: [{ id: "17.1", name: "சமன்பாடுகளைத் தீர்த்தல்" }] },
      { id: "8-18", term: 3, name: "சதவீதம்", periods: 6, subUnits: [{ id: "18.1", name: "சதவீதக் கணிப்புகள்" }] },
      { id: "8-19", term: 3, name: "தொடைகள்", periods: 5, subUnits: [{ id: "19.1", name: "தொடை வகைகள்" }] },
      { id: "8-20", term: 3, name: "பரப்பளவு", periods: 6, subUnits: [{ id: "20.1", name: "முக்கோணியின் பரப்பளவு" }] },
      { id: "8-21", term: 3, name: "காலம்", periods: 5, subUnits: [{ id: "21.1", name: "காலக் கணிப்புகள்" }] },
      { id: "8-22", term: 3, name: "கனவளவும் கொள்ளளவும்", periods: 6, subUnits: [{ id: "22.1", name: "கனவுரு" }] },
      { id: "8-23", term: 3, name: "வட்டம்", periods: 5, subUnits: [{ id: "23.1", name: "வட்டத்தின் இயல்புகள்" }] },
      { id: "8-24", term: 3, name: "இடமொன்றின் அமைவு", periods: 5, subUnits: [{ id: "24.1", name: "திசைகோள்" }] },
      { id: "8-25", term: 3, name: "எண்கோடும் தெக்காட்டின் தளமும்", periods: 6, subUnits: [{ id: "25.1", name: "புள்ளிகளைக் குறித்தல்" }] },
      { id: "8-26", term: 3, name: "முக்கோணி அமைத்தல்", periods: 6, subUnits: [{ id: "26.1", name: "அமைப்பு முறைகள்" }] },
      { id: "8-27", term: 3, name: "தரவுகளை வகைகுறித்தல்", periods: 6, subUnits: [{ id: "27.1", name: "தண்டு இலை வரைபு" }] },
      { id: "8-28", term: 3, name: "அளவிடைப்படம்", periods: 5, subUnits: [{ id: "28.1", name: "அளவிடைப் பிரயோகம்" }] },
      { id: "8-29", term: 3, name: "நிகழ்தகவு", periods: 4, subUnits: [{ id: "29.1", name: "நிகழ்ச்சிகள்" }] },
      { id: "8-30", term: 3, name: "தெசலாக்கம்", periods: 3, subUnits: [{ id: "30.1", name: "பல்கோணி தெசலாக்கம்" }] }
    ]
  },
  {
    grade: "9",
    lessons: [
      { id: "9-1", term: 1, name: "எண்கோலங்கள்", periods: 4, subUnits: [{ id: "1.1", name: "கூட்டல் விருத்தி" }] },
      { id: "9-2", term: 1, name: "துவித எண்கள்", periods: 4, subUnits: [{ id: "2.1", name: "அடி 2 முறைமை" }] },
      { id: "9-3", term: 1, name: "பின்னங்கள்", periods: 6, subUnits: [{ id: "3.1", name: "பின்னக் கணிதச் செய்கைகள்" }] },
      { id: "9-4", term: 1, name: "சதவீதம்", periods: 6, subUnits: [{ id: "4.1", name: "இலாப நட்டம்" }] },
      { id: "9-5", term: 1, name: "அட்சரகணிதக் கோவைகள்", periods: 6, subUnits: [{ id: "5.1", name: "கோவைகளின் பெருக்கம்" }] },
      { id: "9-6", term: 1, name: "அட்சரகணிதக் கோவை களின் காரணிகள்", periods: 6, subUnits: [{ id: "6.1", name: "இருபடி மூவுறுப்புக் கோவை" }] },
      { id: "9-7", term: 1, name: "வெளிப்படையுண்மைகள்", periods: 3, subUnits: [{ id: "7.1", name: "கேத்திர கணித வெளிப்படையுண்மைகள்" }] },
      { id: "9-8", term: 1, name: "சமாந்தரக் கோடுகள் தொடர்பான கோணங்கள்", periods: 6, subUnits: [{ id: "8.1", name: "ஒன்றவிட்ட, ஒத்த கோணங்கள்" }] },
      { id: "9-9", term: 1, name: "திரவ அளவீடு", periods: 4, subUnits: [{ id: "9.1", name: "கனவளவும் கொள்ளளவும்" }] },
      { id: "9-10", term: 2, name: "நேர்விகித சமன்", periods: 5, subUnits: [{ id: "10.1", name: "நேர்விகித சமன் கணக்குகள்" }] },
      { id: "9-11", term: 2, name: "கணிகருவி", periods: 3, subUnits: [{ id: "11.1", name: "கணிகருவியின் பயன்பாடு" }] },
      { id: "9-12", term: 2, name: "சுட்டிகள்", periods: 5, subUnits: [{ id: "12.1", name: "மறைச் சுட்டிகள்" }] },
      { id: "9-13", term: 2, name: "விஞ்ஞானமுறைக் குறிப்பீடும் மட்டந்தட்டலும்", periods: 4, subUnits: [{ id: "13.1", name: "விஞ்ஞானமுறை" }] },
      { id: "9-14", term: 2, name: "ஒழுக்குகளும் அமைப்புக்களும்", periods: 8, subUnits: [{ id: "14.1", name: "அடிப்படை ஒழுக்கு" }] },
      { id: "9-15", term: 2, name: "சமன்பாடுகள்", periods: 7, subUnits: [{ id: "15.1", name: "ஒருங்கமை சமன்பாடுகள்" }] },
      { id: "9-16", term: 2, name: "முக்கோணியொன்றின் கோணங்கள்", periods: 6, subUnits: [{ id: "16.1", name: "அகக்கோணம், புறக்கோணம்" }] },
      { id: "9-17", term: 3, name: "சூத்திரங்கள்", periods: 5, subUnits: [{ id: "17.1", name: "எழுவாய் மாற்றல்" }] },
      { id: "9-18", term: 3, name: "வட்டமொன்றின் பரிதி", periods: 5, subUnits: [{ id: "18.1", name: "பரிதி கணித்தல்" }] },
      { id: "9-19", term: 3, name: "பைதகரசின் தொடர்பு", periods: 5, subUnits: [{ id: "19.1", name: "பைதகரசின் தேற்றம்" }] },
      { id: "9-20", term: 3, name: "வரைபு", periods: 6, subUnits: [{ id: "20.1", name: "நேர்கோட்டு வரைபு" }] },
      { id: "9-21", term: 3, name: "சமனிலிகள்", periods: 5, subUnits: [{ id: "21.1", name: "எளிய சமனிலிகள்" }] },
      { id: "9-22", term: 3, name: "தொடைகள்", periods: 6, subUnits: [{ id: "22.1", name: "வென் வரிப்படங்கள்" }] },
      { id: "9-23", term: 3, name: "பரப்பளவு", periods: 6, subUnits: [{ id: "23.1", name: "வட்டத்தின் பரப்பளவு" }] },
      { id: "9-24", term: 3, name: "நிகழ்தகவு", periods: 5, subUnits: [{ id: "24.1", name: "நிகழ்தகவு கணித்தல்" }] },
      { id: "9-25", term: 3, name: "பல்கோணியின் கோணங்கள்", periods: 6, subUnits: [{ id: "25.1", name: "பல்கோணி அகக்கோணம்" }] },
      { id: "9-26", term: 3, name: "அட்சரகணிதப் பின்னம்", periods: 5, subUnits: [{ id: "26.1", name: "பின்னச் சுருக்கல்" }] },
      { id: "9-27", term: 3, name: "அளவிடைப்படம்", periods: 6, subUnits: [{ id: "27.1", name: "அளவிடைப் படங்கள்" }] },
      { id: "9-28", term: 3, name: "தரவுகளை வகைகுறித்தல்", periods: 6, subUnits: [{ id: "28.1", name: "வட்ட வரைபு" }] }
    ]
  },
  {
    grade: "10",
    lessons: [
      { id: "10-1", term: 1, name: "சுற்றளவு", periods: 5, subUnits: [{ id: "1.1", name: "வில்லின் நீளம்" }] },
      { id: "10-2", term: 1, name: "வர்க்கமூலம்", periods: 4, subUnits: [{ id: "2.1", name: "வகுத்தல் முறை" }] },
      { id: "10-3", term: 1, name: "பின்னங்கள்", periods: 5, subUnits: [{ id: "3.1", name: "பின்னப் பிரசினங்கள்" }] },
      { id: "10-4", term: 1, name: "ஈருறுப்புக் கோவைகள்", periods: 5, subUnits: [{ id: "4.1", name: "கோவை விரிவாக்கம்" }] },
      { id: "10-5", term: 1, name: "ஒருங்கிசைவு", periods: 8, subUnits: [{ id: "5.1", name: "முக்கோணி ஒருங்கிசைவு" }] },
      { id: "10-6", term: 1, name: "பரப்பளவு", periods: 6, subUnits: [{ id: "6.1", name: "ஆரைச்சிறை பரப்பளவு" }] },
      { id: "10-7", term: 1, name: "காரணிகள்", periods: 6, subUnits: [{ id: "7.1", name: "வர்க்க வித்தியாசம்" }] },
      { id: "10-8", term: 1, name: "முக்கோணிகள் -1", periods: 6, subUnits: [{ id: "8.1", name: "முக்கோணித் தேற்றங்கள் 1" }] },
      { id: "10-9", term: 2, name: "முக்கோணிகள் -2", periods: 6, subUnits: [{ id: "9.1", name: "முக்கோணித் தேற்றங்கள் 2" }] },
      { id: "10-10", term: 2, name: "நேர்மாறு விகிதசமன்", periods: 5, subUnits: [{ id: "10.1", name: "வேலையும் நேரமும்" }] },
      { id: "10-11", term: 2, name: "தரவுகளை வகைகுறித்தல்", periods: 8, subUnits: [{ id: "11.1", name: "மீடிறன் பரம்பல்" }] },
      { id: "10-12", term: 2, name: "அட்சரகணிதக் கோவை களின் பொ.ம.சி", periods: 4, subUnits: [{ id: "12.1", name: "பொ.ம.சி காணல்" }] },
      { id: "10-13", term: 2, name: "அட்சரகணிதப் பின்னம்", periods: 5, subUnits: [{ id: "13.1", name: "அட்சரகணிதப் பின்னக் கூட்டல்" }] },
      { id: "10-14", term: 2, name: "சதவீதம்", periods: 6, subUnits: [{ id: "14.1", name: "வரிக்கணக்குகள்" }] },
      { id: "10-15", term: 2, name: "சமன்பாடுகள்", periods: 7, subUnits: [{ id: "15.1", name: "ஒருங்கமை சமன்பாடுகள்" }] },
      { id: "10-16", term: 2, name: "இணைகரங்கள் 1", periods: 8, subUnits: [{ id: "16.1", name: "இணைகரத் தேற்றங்கள்" }] },
      { id: "10-17", term: 3, name: "இணைகரங்கள் 2", periods: 8, subUnits: [{ id: "17.1", name: "நாற்பக்கல் தேற்றங்கள்" }] },
      { id: "10-18", term: 3, name: "தொடைகள்", periods: 6, subUnits: [{ id: "18.1", name: "தொடைகளின் மூலகங்கள்" }] },
      { id: "10-19", term: 3, name: "மடக்கைகள் 1", periods: 5, subUnits: [{ id: "19.1", name: "சுட்டி-மடக்கை தொடர்பு" }] },
      { id: "10-20", term: 3, name: "மடக்கைகள் 2", periods: 6, subUnits: [{ id: "20.1", name: "மடக்கை அட்டவணை" }] },
      { id: "10-21", term: 3, name: "வரைபு", periods: 8, subUnits: [{ id: "21.1", name: "இருபடி வரைபுகள்" }] },
      { id: "10-22", term: 3, name: "வீதம்", periods: 5, subUnits: [{ id: "22.1", name: "வீதக் கணக்குகள்" }] },
      { id: "10-23", term: 3, name: "சூத்திரங்கள்", periods: 5, subUnits: [{ id: "23.1", name: "சூத்திரப் பிரயோகம்" }] },
      { id: "10-24", term: 3, name: "கூட்டல் விருத்தி", periods: 7, subUnits: [{ id: "24.1", name: "n ஆம் உறுப்பு" }] },
      { id: "10-25", term: 3, name: "அட்சரகணிதச் சமனிலிகள்", periods: 5, subUnits: [{ id: "25.1", name: "சமனிலித் தீர்வு" }] },
      { id: "10-26", term: 3, name: "மீடிறன் பரம்பல்", periods: 8, subUnits: [{ id: "26.1", name: "இடை காணல்" }] },
      { id: "10-27", term: 3, name: "வட்டத்தின் நாண்கள்", periods: 7, subUnits: [{ id: "27.1", name: "நாண் தேற்றங்கள்" }] },
      { id: "10-28", term: 3, name: "அமைப்புக்கள்", periods: 6, subUnits: [{ id: "28.1", name: "நாற்கோண அமைப்பு" }] },
      { id: "10-29", term: 3, name: "மேற்பரப்பும கனவளவும்", periods: 8, subUnits: [{ id: "29.1", name: "உருளை, கனவுரு" }] },
      { id: "10-30", term: 3, name: "நிகழ்தகவு", periods: 5, subUnits: [{ id: "30.1", name: "மரவரிப்படங்கள்" }] },
      { id: "10-31", term: 3, name: "வட்டத்தின் கோணங்கள்", periods: 7, subUnits: [{ id: "31.1", name: "கோணத் தேற்றங்கள்" }] },
      { id: "10-32", term: 3, name: "அளவிடைப்படங்கள்", periods: 6, subUnits: [{ id: "32.1", name: "ஏற்றக்கோணம், இறக்கக்கோணம்" }] }
    ]
  },
  {
    grade: "11",
    lessons: [
      { id: "11-1", term: 1, name: "மெய்யெண்கள்", periods: 4, subUnits: [{ id: "1.1", name: "விகிதமுறா எண்கள்" }] },
      { id: "11-2", term: 1, name: "சுட்டிகளும் மடக்கைகளும் 1", periods: 6, subUnits: [{ id: "2.1", name: "மடக்கை விதிகள்" }] },
      { id: "11-3", term: 1, name: "சுட்டிகளும் மடக்கைகளும் 2", periods: 6, subUnits: [{ id: "3.1", name: "மடக்கை அட்டவணைப் பயன்பாடு" }] },
      { id: "11-4", term: 1, name: "திண்மங்களின் மேற்பரப்பளவு", periods: 6, subUnits: [{ id: "4.1", name: "கூம்பு, கோளம்" }] },
      { id: "11-5", term: 1, name: "திண்மங்களின் கனவளவு", periods: 6, subUnits: [{ id: "5.1", name: "திண்மங்களின் கனவளவு கணித்தல்" }] },
      { id: "11-6", term: 1, name: "ஈருறுப்புக் கோவையின் விரிவு", periods: 5, subUnits: [{ id: "6.1", name: "கன விரிவாக்கம்" }] },
      { id: "11-7", term: 1, name: "அட்சரகணிதப் பின்னம்", periods: 5, subUnits: [{ id: "7.1", name: "பின்னப் பெருக்கல் வகுத்தல்" }] },
      { id: "11-8", term: 1, name: "சமாந்தரக் கோடுகளுக்கிடையிலான தளவுருவங்களின் பரப்பளவுகள்", periods: 8, subUnits: [{ id: "8.1", name: "பரப்பளவு தேற்றங்கள்" }] },
      { id: "11-9", term: 2, name: "சதவீதம்", periods: 6, subUnits: [{ id: "9.1", name: "நிதி கணிதச் சதவீதம்" }] },
      { id: "11-10", term: 2, name: "பங்குச்சந்தை", periods: 6, subUnits: [{ id: "10.1", name: "பங்குச் சந்தை லாபம்" }] },
      { id: "11-11", term: 2, name: "நடுப்புள்ளிகள் தேற்றம்", periods: 8, subUnits: [{ id: "11.1", name: "நடுப்புள்ளித் தேற்றப் பிரயோகம்" }] },
      { id: "11-12", term: 2, name: "வரைபு", periods: 10, subUnits: [{ id: "12.1", name: "பரவளைய வரைபுகள்" }] },
      { id: "11-13", term: 2, name: "சமன்பாடுகள்", periods: 8, subUnits: [{ id: "13.1", name: "இருபடிச் சமன்பாடுகள்" }] },
      { id: "11-14", term: 2, name: "இயல்பொத்த முக்கோணிகள்", periods: 8, subUnits: [{ id: "14.1", name: "இயல்பொத்த இயல்புகள்" }] },
      { id: "11-15", term: 2, name: "தரவுகளை வகைகுறித்தல்", periods: 8, subUnits: [{ id: "15.1", name: "திரள் மீடிறன் வளைவு" }] },
      { id: "11-16", term: 3, name: "பெருக்கல் விருத்தி", periods: 7, subUnits: [{ id: "16.1", name: "பெருக்கல் விருத்தி n ஆம் உறுப்பு" }] },
      { id: "11-17", term: 3, name: "பைதகரசின் தேற்றம்", periods: 5, subUnits: [{ id: "17.1", name: "தேற்றப் பிரயோகம்" }] },
      { id: "11-18", term: 3, name: "திரிகோண கணிதம்", periods: 10, subUnits: [{ id: "18.1", name: "திரிகோண கணித விகிதங்கள்" }] },
      { id: "11-19", term: 3, name: "தாயம்", periods: 6, subUnits: [{ id: "19.1", name: "தாயம் பெருக்கல்" }] },
      { id: "11-20", term: 3, name: "சமனிலிகள்", periods: 6, subUnits: [{ id: "20.1", name: "கூட்டுச் சமனிலிகள்" }] },
      { id: "11-21", term: 3, name: "வட்ட நாற்பக்கல்கள்", periods: 8, subUnits: [{ id: "21.1", name: "வட்ட நாற்பக்கல் தேற்றங்கள்" }] },
      { id: "11-22", term: 3, name: "தொடலிகள்", periods: 10, subUnits: [{ id: "22.1", name: "வட்டத் தொடலித் தேற்றங்கள்" }] },
      { id: "11-23", term: 3, name: "அமைப்பு", periods: 6, subUnits: [{ id: "23.1", name: "வட்ட அமைப்புகள்" }] },
      { id: "11-24", term: 3, name: "தொடைகள்", periods: 8, subUnits: [{ id: "24.1", name: "மூன்று தொடைகள்" }] },
      { id: "11-25", term: 3, name: "நிகழ்தகவு", periods: 8, subUnits: [{ id: "25.1", name: "சார் நிகழ்ச்சிகள்" }] }
    ]
  }
];

export const TEXTBOOKS: TextbookLink[] = [
  { grade: "6", parts: [
    { title: "கணிதம் I", url: "http://www.edupub.gov.lk/Administrator/Tamil/6/maths%20g-6%20p-I%20T/maths%20g-6%20p-I%20T.pdf" },
    { title: "கணிதம் II", url: "http://www.edupub.gov.lk/Administrator/Tamil/6/maths%20g-6%20p-II%20T/maths%20g-6%20p-II%20T.pdf" }
  ]},
  { grade: "7", parts: [
    { title: "கணிதம் I", url: "http://www.edupub.gov.lk/Administrator/Tamil/7/maths%20G-7%20P-I%20T/Maths%20G%207%20Part1.pdf" },
    { title: "கணிதம் II", url: "http://www.edupub.gov.lk/Administrator/Tamil/7/maths%20P-II%20T/maths%20P-II%20T.pdf" }
  ]},
  { grade: "8", parts: [
    { title: "கணிதம் I", url: "http://www.edupub.gov.lk/Administrator/Tamil/8/maths%20P-I%20TG-8/maths%20G-8%20I%20T.pdf" },
    { title: "கணிதம் II", url: "http://www.edupub.gov.lk/Administrator/Tamil/8/maths%20G-8%20P-II%20T/maths%20G-8%20P-II%20T.pdf" }
  ]},
  { grade: "9", parts: [
    { title: "கணிதம் I", url: "http://www.edupub.gov.lk/Administrator/Tamil/9/maths%20g9%20p-I%20S/maths%20g-9%20P-I%20T.pdf" },
    { title: "கணிதம் II", url: "http://www.edupub.gov.lk/Administrator/Tamil/9/maths%20G-9%20P-II%20T/m%20G9%20PII%20T.pdf" }
  ]},
  { grade: "10", parts: [
    { title: "கணிதம் I", url: "http://www.edupub.gov.lk/Administrator/Tamil/10/maths%20g-10%20p-I%20T/Maths%20Gr%2010%20P%20I%20(T).pdf" },
    { title: "கணிதம் II", url: "http://www.edupub.gov.lk/Administrator/Tamil/10/maths%20g-10%20p-II%20T/maths%20g-10%20p-II%20T.pdf" }
  ]},
  { grade: "11", parts: [
    { title: "கணிதம் I", url: "http://www.edupub.gov.lk/Administrator/Tamil/11/maths%20g-11%20p-I%20T/maths%20G-11%20P-I%20T.pdf" },
    { title: "கணிதம் II", url: "http://www.edupub.gov.lk/Administrator/Tamil/11/mat%20g-11%20p-II%20T/maths%20g-11%20p-II%20T.pdf" }
  ]}
];

export const NIE_GUIDES: NIELink[] = [
  { grade: "6", url: "https://nie.lk/pdffiles/tg/t6tim109.pdf" },
  { grade: "7", url: "https://nie.lk/pdffiles/tg/t7tim168.pdf" },
  { grade: "8", url: "https://nie.lk/pdffiles/tg/tGr8_TG%20Maths.pdf" },
  { grade: "9", url: "https://nie.lk/pdffiles/tg/tGr09TG%20Maths.pdf" },
  { grade: "10", url: "https://nie.lk/pdffiles/tg/t10tim109.pdf" },
  { grade: "11", url: "https://nie.lk/pdffiles/tg/t11tim168.pdf" }
];
